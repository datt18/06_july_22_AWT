function my() {
    alert('hello');
}
console.log('hello i am datt patel');
function e(){
    document.body.style.backgroundColor=prompt('enter the color');

}
function r(){
    document.getElementById('d').style.backgroundColor="red";
}
function n(){
    document.getElementById('w').style.backgroundColor="blue";

}
function p(){
    document.body.style.backgroundColor=document.getElementById('q').value;
}
function a(){
    document.getElementById('u').style.backgroundColor=document.getElementById('o').value;;

}
function f1(){
    var vn1= prompt("enter name");
    document.getElementById('text').innerHTML = vn1;
}
function f2(){
    var v1 = prompt("enter frist name");
    var v2 = prompt("enter last name");
    document.getElementById('h').innerHTML = v1;
    document.getElementById('e').innerHTML = v2;

}


   